package kalman;

public class Exponential {

	public static void main(String []args)
	{
		System.out.println(Math.E);
	}
}
